package com.hundredwordsgof.flyweightobserver;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * FlyweightFactory, creates and manages the flyweight objects.
 *
 */
public interface FlyweightFactory {
 // No shared methods (yet)
}
